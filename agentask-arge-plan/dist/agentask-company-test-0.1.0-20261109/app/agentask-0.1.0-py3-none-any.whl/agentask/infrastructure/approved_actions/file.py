"""APPROVED_ACTION_SET=file: kurumun onayladığı aksiyonlar tipli JSON dosyasından okunur."""

from __future__ import annotations

from pathlib import Path

from pydantic import ValidationError

from agentask.config.errors import ConfigurationError
from agentask.domain.actions import ActionSet


def load_action_set(path: Path) -> ActionSet:
    try:
        actions = ActionSet.model_validate_json(path.read_bytes())
    except OSError:
        raise ConfigurationError(["APPROVED_ACTIONS_FILE okunamadı."]) from None
    except ValidationError as exc:
        fields = sorted({".".join(str(p) for p in e["loc"]) for e in exc.errors(include_input=False)})[:10]
        raise ConfigurationError([f"APPROVED_ACTIONS_FILE geçersiz: {', '.join(fields)}"]) from None
    wrong = [key for key, action in actions.actions.items() if key != action.action_id]
    if wrong:
        raise ConfigurationError(["APPROVED_ACTIONS_FILE: anahtar ile action_id aynı olmalı."])
    return actions
