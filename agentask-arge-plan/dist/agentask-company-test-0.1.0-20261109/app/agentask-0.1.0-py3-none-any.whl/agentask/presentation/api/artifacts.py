"""Dosya/kanıt indirme (ADR 0016). Sahip kontrollü; imzalı bağlantı yok, içerik bu uçtan akıtılır."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Path, Response

from agentask.domain.artifacts import ARTIFACT_ID_PATTERN
from agentask.presentation.dependencies import ContainerDep, PrincipalDep

router = APIRouter(prefix="/api/artifacts", tags=["artifacts"])


@router.get("/{artifact_id}")
async def download(
    artifact_id: Annotated[str, Path(pattern=ARTIFACT_ID_PATTERN)], p: PrincipalDep, c: ContainerDep
) -> Response:
    ref, data = await c.artifacts.fetch(p.user_id, artifact_id)
    return Response(
        content=data,
        media_type=ref.content_type,
        headers={
            "Content-Disposition": f'attachment; filename="{ref.artifact_id}"',
            "Cache-Control": "no-store",
        },
    )
