# AgenTask — Pega katalog tabanlı otomasyon: uygulama geliştirme paketi

Sürüm: 1.0 · Tarih: 2026-11-05 · Durum: Ar-Ge uygulama şartnamesi.
Bu paket uygulama kaynak kodu değildir. Claude Code'un uygulamayı geliştirmesi için bağlam, görevler, sözleşmeler ve doğrulama koşulları içerir. Gerçek Pega sisteminde test edilmiş başarı iddiası içermez.

## Kullanım
1. Arşivi boş bir proje klasörüne açın. Mevcut depoda kullanılacaksa önce mevcut CLAUDE.md/AGENTS.md talimatlarını okuyup çakışmaları birleştirin; dosyaları körlemesine ezmeyin.
2. Claude Code'u bu klasörde başlatın. Önce CLAUDE.md, sonra docs/00_SCOPE_AND_DECISIONS.md, docs/06_IMPLEMENTATION_PLAN.md ve docs/10_PROGRESS.md dosyalarını okumasını isteyin.
3. Aşağıdaki başlangıç talimatını kullanın. Paket bir uygulamayı dış ortama yayımlama talimatı vermez.

> CLAUDE.md ve referans verdiği proje belgelerini oku. Önce mevcut çalışma alanını incele. docs/06_IMPLEMENTATION_PLAN.md içindeki P0'dan başlayarak uygulamayı geliştir. Ortama bağlı bütün ayarlar tek Settings katmanından .env/ortam değişkenleriyle okunacak. Her aşamada anlamlı testleri çalıştır ve docs/10_PROGRESS.md dosyasını güncelle. Rutin ve geri alınabilir uygulama kararlarında durmadan ilerle. Pega erişimi veya kurum bilgisi gerektiren bilinmeyenleri gerçekmiş gibi üretme; port ve test ikamesiyle ilerle, gerçek sistem doğrulamasını bekleyen olarak işaretle. Katalogda kalıcı selector tutma; model önerileri doğrudan çalıştırılmasın. Uygulamayı yalnızca yerel Ar-Ge ortamında çalıştır; gerçek banka işlemi veya dış dağıtım yapma.

## Okuma sırası
- [Claude Code talimatları](CLAUDE.md)
- [Kapsam ve kararlar](docs/00_SCOPE_AND_DECISIONS.md)
- [Mimari](docs/01_ARCHITECTURE.md)
- [Katalog ve plan sözleşmeleri](docs/02_CATALOG_CONTRACTS.md)
- [Çalışma motoru ve kurtarma](docs/03_RUNTIME_AND_RECOVERY.md)
- [Arayüz ve katalog hazırlama](docs/04_UI_AND_AUTHORING.md)
- [.env ve yapılandırma](docs/05_CONFIGURATION.md)
- [Uygulama planı](docs/06_IMPLEMENTATION_PLAN.md)
- [Test ve kabul](docs/07_ACCEPTANCE_TESTS.md)
- [Güvenlik ve izleme](docs/08_SECURITY_AND_OPERATIONS.md)
- [API sözleşmeleri](docs/09_API_CONTRACTS.md)
- [İlerleme kaydı](docs/10_PROGRESS.md)
- [Teknik kaynaklar](docs/11_REFERENCES.md)

.env.example yalnızca güvenli Ar-Ge örnek ayarları içerir. Gerçek parolalar, banka adresleri veya kullanıcı verileri yoktur. Kopyalayıp .env oluşturun; .env dosyasını sürüm kontrolüne eklemeyin.
