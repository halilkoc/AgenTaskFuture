# Bütün ortam ayarları .env üzerinden

## Bağlayıcı kural
URL/host/port, bağlantı bilgileri, model adı ve auth, CA/TLS, browser/headless, dosya yolları, timeout, token/step/scan/retry limitleri, log seviyesi ve özellik bayrakları kaynak koduna gömülmez. Tek typed Settings sınıfından okunur. Aynı anahtarlar .env.example içinde açıklamalı ve güvenli örneklerle bulunur.
Öncelik: process environment > seçili .env dosyası. Varsayılan dosya repo kökündeki .env; başka dosya yolu bootstrap'ta açık --env-file ile seçilebilir. Settings dışındaki modüller os.getenv/dotenv çağırmaz. İş verileri, kataloglar, workflow parametreleri ve sıradan fonksiyon değişkenleri .env'ye taşınmaz. Değişmez protocol enum'ları ve kod sabitleri de konfigürasyon değildir.
Katalogdaki operasyon politikaları .env limitlerini aşamaz; .env sistem üst sınırıdır. Sayısal limit bir iş yetkisi vermez.

## Tip ve güvenlik
Pydantic Settings ile startup validation; boolean 'false' gerçekten false, pozitif limitler ve URL/enum doğrulaması; geçersiz değer sessizce default'a düşmez. SecretStr ve redakte hata mesajları. İlgisiz process env yok sayılabilir; seçili dotenv içindeki bilinmeyen uygulama anahtarları yazım hatası olarak reddedilir.
LLM_ENABLED=false iken model credential zorunlu değil. true ise endpoint/model/auth modu için gereken alanlar zorunlu. TLS_VERIFY=true temel ayar; CA_BUNDLE isteğe bağlıdır. verify=false yalnızca development'ta açık seçilmişse kullanılabilir; varsayılan değildir.
Production: dev identity adapteri, http dış servise credential taşıma ve güvenlik kontrollerini kapatan modlar reddedilir. AUTH_MODE=unconfigured gerçek ortama hazır auth değildir.
.env gitignored; .env.example sürümlenir. Build image içinde secret/.env yok. OpenShift gelecekte aynı env isimlerini Secret/ConfigMap veya güvenli .env mount ile verebilir; kod değişmez.
Frontend'e backend Settings dökümü verilmez. Public config endpoint sadece allowlist alanları verir; Mongo/LLM/SSO secretları frontend bundle veya VITE değişkenleriyle dışarı çıkmaz. Kullanıcı oturum sırları kalıcı .env içinde tutulmaz.

## Temel ayar grupları
- APP_ENV, APP_HOST, APP_PORT, APP_TIMEZONE, APP_BASE_URL, AUTH_MODE, DEV_AUTH_ENABLED, SESSION_SIGNING_KEY
- MONGO_URI, MONGO_DATABASE, MONGO_TLS_CA_FILE, MONGO_SERVER_SELECTION_TIMEOUT_MS
- DRAFT_BACKEND, DRAFT_DIRECTORY, ARTIFACT_DIRECTORY, RUNNER_MODE, BROWSER_ENGINE, BROWSER_HEADLESS, BROWSER_EXECUTABLE_PATH, PLAYWRIGHT_BROWSERS_PATH
- TARGET_ALLOWED_ORIGINS, TARGET_BASE_URL; örnek hedef sadece 127.0.0.1 test uygulaması
- ACTION_TIMEOUT_MS, READINESS_TIMEOUT_MS, FRAME_SCAN_TIMEOUT_MS, FRAME_SCAN_MAX_DEPTH, FRAME_SCAN_MAX_ELEMENTS, FRAME_SCAN_CONCURRENCY
- RUN_MAX_STEPS, RUN_MAX_DURATION_SECONDS, TABLE_MAX_PAGES, TABLE_MAX_ROWS, RECOVERY_MAX_ATTEMPTS, SESSION_LEASE_SECONDS
- LLM_ENABLED, LLM_BASE_URL, LLM_MODEL, LLM_AUTH_MODE, LLM_API_KEY, LLM_USERNAME, LLM_PASSWORD, LLM_TLS_VERIFY, LLM_CA_BUNDLE, LLM_TIMEOUT_SECONDS
- LLM_CONTEXT_TOKENS, LLM_MAX_INPUT_TOKENS, LLM_MAX_OUTPUT_TOKENS, LLM_CONTEXT_RESERVE_TOKENS, LLM_MAX_CALLS_PER_RUN
- LOG_LEVEL, LOG_FORMAT, EVIDENCE_RETENTION_DAYS, EVIDENCE_SCREENSHOTS_ENABLED

Context değerleri modelin gerçek sınırı öğrenildiğinde ayarlanır. input+output+reserve <= context startup kontrolü yap. Reasoning tokenları provider sınırına göre output/reserve içinde hesaba katılmalı. Tokenizer yoksa tahminin kesin olmadığını bildir ve conservative budget uygula; limitsiz gönderme.
Varsayılanları .env.example'dan Settings'e iki ayrı yerde kopyalamak yerine zorunlu alanlar/tek kaynak yaklaşımı seç. Gereken yeni bir ayar eklendiğinde bu belge, .env.example ve config testi birlikte güncellenir.
