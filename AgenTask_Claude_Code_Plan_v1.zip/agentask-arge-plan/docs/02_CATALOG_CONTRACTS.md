# Katalog, yayın ve plan sözleşmeleri

## Mantıksal veri modeli
| Varlık | Zorunlu içerik |
|---|---|
| Application | application_id, name, environment binding reference |
| Screen | screen_id, revision, recognition rules, logical regions |
| Element | element_id, semantic meaning, labels/roles, region/context, control behavior, matching constraints |
| Operation | operation_id, revision, intent phrases, typed parameters, preconditions, actions, effects, postconditions, retry/reconciliation policy, authorization reference |
| Release | release_id, application/environment, exact immutable definition revisions, schema/adapter requirements, content hash, test and approval references |
| Plan | plan_id, release_id/hash, typed arguments, supported operation references, compiler version, actor/session binding |

Tanımlar JSON Schema/Pydantic discriminated union olarak doğrulanır; unknown field/op/check reddedilir. Arbitrary Python/JS, eval, CSS/XPath veya serbest URL komutu kabul edilmez.
Element kimliği HTML id değildir. Fiziksel locator, koordinat ve frame sırası kalıcı hedef tanımı olamaz. Reference screenshot isteğe bağlı yardımcı kanıt, tek başına eşleştirme yetkisi değildir.

## Element eşleştirmesi
Örnek: element_id=working_branch; meaning=branch_code_selection; labels=[Şube,Çalışma Şubesi]; behavior=single_choice; logical_region=session_context; unique=true.
Adlar işaret/harf normalizasyonuyla karşılaştırılabilir; kayıt/şube kimlikleri metin olarak tutulur, baştaki sıfırlar korunur. Yakınlık eşleşmesi farklı iş kimliğini kabul ettiremez.
Mantıksal bölge ve ekran tanımları da somut gözlemlerle çözülmeli; açıklaması olmayan döngüsel 'screen doğruysa element doğru' doğrulaması kurma. Gerekli/opsiyonel kanıtlar açık olmalı.

## İşlem örneği (kavramsal)
operation=change_working_branch; parameter=branch_code:string; effect=session_context_change;
preconditions=authenticated + recognized_screen + authorized_branch;
action=ensure_choice(working_branch, branch_code);
postcondition=active_branch == branch_code;
on_uncertain=read_state_then_stop_if_unresolved.
Gerçek ekranda Uygula düğmesi gerekiyorsa bunun tanımı ve etkisi ayrıca eklenir; motor varsaymaz.

## Komut dili
MVP: read, ensure_value, ensure_choice, activate_tab, find_record, invoke_approved_action, assert_condition. 'invoke_approved_action' effect ve outcome check olmadan geçersizdir.
Kod tarafında kayıtlı kontrol adapterleri komutu fiziksel etkileşime çevirir. Genel sınırsız 'click any element' iş yeteneği sunma.
Sonraki faz: if(condition), call_operation, for_each(collection,max_items). Tip, veri akışı, kaynak kapsamı, çağrı döngüsü ve toplam adım bütçesi doğrulanır. Desteklenmeyen yapı reddedilir.
Plan derleme kontrolü niyetin matematiksel doğruluk kanıtı değildir. Belirsiz işlem/parametre kullanıcının açıklamasını gerektirir.

## MongoDB
catalog_screens, catalog_operations: application_id + entity_id + revision unique; sadece yayımlama servisi yazar.
catalog_releases: release_id unique; immutable tanım manifestosu, içerik hash'i ve test/onay referansları.
catalog_active_releases: application_id + environment unique; etkin release pointer.
automation_runs: run_id unique; actor/status/time/release indeksleri.
Mongo schema validation ve Pydantic doğrulaması birlikte; dangling reference ve şema uyumu release öncesi kontrol edilir. Ekrana ait sınırlı element listesi ekran dokümanında gömülebilir; bütün katalog tek sınırsız doküman olmaz.

## Tutarlı yayımlama
Önce tüm immutable revisions idempotent upsert/insert ile yazılır; aynı id+revision farklı hash ile yeniden yazılamaz. Ardından complete release manifest yazılır ve tüm referanslar doğrulanır. En son aktif pointer compare-and-set ile değiştirilir. Eksik yayın runtime tarafından okunamaz. Replica set varsa transaction opsiyoneldir; standalone Mongo'da da pointer-last yaklaşımı güvenli olmalıdır.
Onay kullanıcı kimliği + canonical content hash + test evidence hash + adapter/schema versions ile bağlıdır. Düzenleme onayı geçersiz kılar. Testten sonra değişen içerik yayımlanmaz. Approval durumu istemcinin gönderdiği boolean'dan alınmaz.
Runtime iş başında release'i pin eder. Eski release'e dönmek bitmiş işlemleri geri almaz. Süregelen run değişmez; açık revocation/kill durumu durdurabilir. Devamda güncel kullanıcı yetkisi yine kontrol edilir.
