# API sözleşmesi taslağı

Bütün private endpoint'ler identity/policy/ownership kontrolü yapar. Request/response Pydantic; OpenAPI güncel tutulur. Aşağıdaki yollar başlangıç sözleşmesidir; implementasyon değişirse bu belge güncellenir.

| Method/path | Amaç |
|---|---|
| GET /health/live, /health/ready | Sağlık |
| GET /api/me | Kimlik ve yetenekler; secret yok |
| GET /api/config/public | Allowlist public UI config |
| POST /api/sessions | İzole browser session |
| DELETE /api/sessions/{id} | Sahibinin session'ını kapat |
| POST /api/sessions/{id}/observe | Bütçeli observation; snapshot_revision/coverage |
| POST /api/drafts | Yerel taslak başlat |
| GET/PATCH /api/drafts/{id} | Versiyon kontrollü oku/düzenle |
| POST /api/drafts/{id}/steps/propose | Intent → öneri; dispatch yok |
| POST /api/drafts/{id}/steps/{step}/select-target | Geçici candidate + snapshot ref |
| POST /api/drafts/{id}/steps/{step}/confirm | Anlam/hedef/parametre/etki onayı |
| POST /api/drafts/{id}/steps/{step}/trial | Gerçek kontrollü deneme |
| POST /api/drafts/{id}/validate | Şema/referans ve test kapsamı |
| POST /api/drafts/{id}/approve | İçerik/test hash'e bağlı server approval |
| POST /api/drafts/{id}/publish | Publisher yetkisi, idempotent release |
| GET /api/catalogs/releases | Yetkili release listesi |
| POST /api/plans | Prompt+release → açıklama veya doğrulanacak plan |
| POST /api/runs | Sunucuda yeniden validate edilmiş planı çalıştır |
| GET /api/runs/{id} | Durum ve redakte adım sonuçları |
| POST /api/runs/{id}/cancel | İptal talebi |
| POST /api/runs/{id}/resume | Gerekli bağlam/yetki doğrulamasıyla devam |
| GET /api/runs/{id}/events | Yetkili SSE/WS progress |
| POST /api/catalogs/impact-analysis | Yeni observation ile anlamsal diff |

Candidate id runtime scope'tadır: session/snapshot/generation ile bağlıdır. Stale candidate HTTP 409 üretir veya açık yeniden çözüm ister. Kullanıcıdan alınan selector çalıştırılmaz.
Long-running trial/run 202 + job/run id döndürür; browser işini HTTP timeout'a bağlama. session lease koşulları uygulanır.
Mutating create/run/publish request_id/idempotency key taşır. Aynı key farklı payload hash ile conflict. Draft update expected_revision/If-Match kullanır. Client approve=true göndermek yeterli değildir.
Error envelope: code, safe_message, correlation_id, retryable, details (redacted). Teknik retryable bayrağı belirsiz write'ı tekrar etme yetkisi değildir.
409: stale/ambiguous/conflict; 422: schema/unsupported plan; 403: policy; 503: etkin dependency unavailable. Outcome_unknown başarılı HTTP response içinde de açık run state olabilir.
